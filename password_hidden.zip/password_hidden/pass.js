let eyeopen=document.querySelector("#eyeopen");
let eyeclose=document.querySelector("#eyeclose");
let inputvalue=document.querySelector("#pass");


eyeopen.addEventListener("click",()=>
{
          
         
         eyeopen.classList.toggle("active");

         conversion();
         
       

})
eyeclose.addEventListener("click",()=>
{
          
          eyeclose.classList.toggle("active");
          conversion();

})

function conversion()
{
          if(inputvalue.type==="password")
          {
                    inputvalue.type="text";
          }
          else{
                    inputvalue.type="password";   
          }
}