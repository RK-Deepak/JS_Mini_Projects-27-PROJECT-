const playername=document.querySelector("#player_info");
const tictac=document.querySelectorAll(".box");
const newgamebtn=document.querySelector(".btns");

//some variables
let currentplayer;//which current player is playing
let gridvaluejs;//ke js me uss box ke baare me batayeg

//winning scenario ke iss position of same element aaye to jitega
const winning_scenario=
[[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
];
//when game initalized or after game complete reset
initalizegame();
function initalizegame()
{
   currentplayer="X";//AT start we took X as current player
   playername.innerText=`Current Player - ${currentplayer}`;//update 
//    current player name
gridvaluejs=["","","","","","","","",""];//nothing in boxes 
   newgamebtn.classList.remove("active");//when new game or bwtween the game new game button is removed
   //ab game reset hua ya starthua to kuch property

   tictac.forEach((box,index)=>
   {
     box.innerText="";
     tictac[index].style.pointerEvents="all"
     box.classList=`box box-${index+1}`;
   })
}
//lets handle when something is clicked or x or 0
function swapturn()
{
     if(currentplayer=="X")
     {
          currentplayer="O";

     }
     else
     {
          currentplayer="X";
     }
     playername.innerText=`Current Player is-${currentplayer}`;
}
function checkgamefinish()
{
     let winner="";
     //we will check all winning scaenario if it occurs or not
     winning_scenario.forEach((position)=>
     {
          if( (gridvaluejs[position[0]] !== "" && gridvaluejs[position[1]] !== "" && gridvaluejs[position[2]] !== "") 
          && (gridvaluejs[position[0]] === gridvaluejs[position[1]] ) && (gridvaluejs[position[1]] === gridvaluejs[position[2]]))
          {
            
            if(gridvaluejs[position[0]]==="X")
            {
               winner="X";
            }
            else
            {
               winner="O";
            }

            tictac.forEach((box)=>
            {
               box.style.pointerEvents="none";
            })

           tictac[position[0]].classList.add("win_bg");
           tictac[position[1]].classList.add("win_bg");

           tictac[position[2]].classList.add("win_bg");


          }
          if(winner!=="")
          {
               playername.innerText= `Winner Player- ${winner}`;
               newgamebtn.classList.add("active");
               return;
          }
          //handele tie case
          
               let fillcount=0;
               gridvaluejs.forEach((box)=>
               {
                    if(box!=="")
                    {
                         fillcount++;
                    }
               });
               if(fillcount === 9)
               {
                    playername.innerText="Game tied";
                    newgamebtn.classList.add("active");
               }
     });

          
          
              
          }

function handleclick(index)
{
     if(gridvaluejs[index]==="")
     {
          //ui update
          playername.innerText=currentplayer;
          gridvaluejs[index]=currentplayer;
          tictac[index].style.pointerEvents="none";
          tictac[index].innerText=currentplayer;


     }
     swapturn();

     checkgamefinish();
    


}

//go to each box and applied event listender
tictac.forEach((box,index)=>
{
       box.addEventListener("click",()=>
       {
          handleclick(index);
       })
})
newgamebtn.addEventListener("click",initalizegame);


