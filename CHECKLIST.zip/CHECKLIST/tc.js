let playerinfo=document.querySelector("#player_info");
let tictac=document.querySelectorAll(".box");
let newgamebn=document.querySelector(".btns");

let currentplayer;
let gridvaluejs;

const winning_scenario=
[[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
];

initalizegame();
//game start or reset
function initalizegame()
{
     currentplayer="X";
     gridvaluejs=["","","","","","","","",""];

     playerinfo.innerText=`Current Player -${currentplayer}`;

     //ab man lo jeet gaye to reset krna hoga woh krte bad me

     tictac.forEach((box,index)=>
     {
          box.innerText="";
          tictac[index].style.pointerEvents="all";
          box.classList=`box box-${index+1}`;
     })

     newgamebn.classList.remove("active");

  

}
function swapturn()
{
     if(currentplayer=="X")
     {
          currentplayer="O"
     }
     else{
          currentplayer="X";
     }
     playerinfo.innerText=`Current Player -${currentplayer}`;
}
function checkgamefinish()
{
     let winner="";

     winning_scenario.forEach((position)=>
     {
         if((gridvaluejs[position[0]]!=="" && gridvaluejs[position[1]]!=="" && gridvaluejs[position[2]]!=="") && (gridvaluejs[position[0]]===gridvaluejs[position[1]] )&& (gridvaluejs[position[1]]===gridvaluejs[position[2]] ))
         {
              if(gridvaluejs[position[0]]==="X")
              {
                winner="X";
              }
              else
              {
               winner="O";
              }
         
         tictac.forEach((element)=>
         {
          element.style.pointerEvents="none";
         })

         tictac[position[0]].classList.add("win_bg");
         tictac[position[1]].classList.add("win_bg");
         tictac[position[2]].classList.add("win_bg");

     }

         if(winner!=="")
         {
          playerinfo.innerText=`Winner Player- ${winner}`;
          newgamebn.classList.add("active");
          return;
         }
         //lets handle tie case
         let fillcount=0;
         gridvaluejs.forEach((box)=>
         {
             if(box!=="")
             {
               fillcount++;
             }
         });
         if(fillcount === 9)
         {
          playerinfo.innerText="Game tied";
          newgamebn.classList.add("active");
         }
     
     })
}
function handleclick(index)
{
     if(gridvaluejs[index]==="")
     {
          // playerinfo.innerText=currentplayer;
          // playerinfo.innerText=currentplayer;
          gridvaluejs[index]=currentplayer;
          tictac[index].innerText=currentplayer;
          tictac[index].style.pointerEvents="none";

     }
     swapturn();

     checkgamefinish();
}
//tictac ke har element pe x and 0 likha


tictac.forEach((element,index)=>
{
     element.addEventListener("click",()=>
     {
          handleclick(index);
     })

     
})

newgamebn.addEventListener("click",initalizegame);
