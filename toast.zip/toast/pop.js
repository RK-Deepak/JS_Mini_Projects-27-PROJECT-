let toastbox=document.querySelector("#toastbox");

let errormessage='<i class="fa-regular fa-circle-xmark fa-xl" style="color: #e00000;"></i>Error Found';
let successmessage='<i class="fa-solid fa-check" style="color: #00d118;"></i>Successfull Op';
let invalidmessage='<i class="fa-solid fa-bomb" style="color: #e5360b;"></i>Invalid';
function showToast(msg)
{
          let createelement=document.createElement("div");
          createelement.classList.add("toast");
          
         
          
    createelement.innerHTML=msg;
          
         

       
          toastbox.appendChild(createelement);
          if(msg.includes("Found"))
          {
                    createelement.classList.add("error");
          }
          if(msg.includes("Op"))
          {
                    createelement.classList.add("success");
          }
          if(msg.includes("Invalid"))
          {
                    createelement.classList.add("invalid");
          }


          setTimeout(()=>
          {
                    toastbox.removeChild(createelement);
          },6000);
}




