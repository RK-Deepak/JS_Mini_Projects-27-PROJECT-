let name_error=document.querySelector("#name-error");
let phone_error=document.querySelector("#phoneno");
let email_error=document.querySelector("#emailx");
let text_error=document.querySelector("#txtarea");
let button_error=document.querySelector("#Submit-error");

let fname=document.querySelector("#fname");
let phone=document.querySelector("#phone");
let email=document.getElementById("email");
let text=document.querySelector("#txt");

let btns=document.querySelector("#btns");


function checkfullname()
{
          let name=fname.value;
          if(name.length==0)
          {
                    name_error.innerHTML="Name Required";
                    name_error.classList.add("active");
                    return false;
                    
          }
          if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/))
          {
                    name_error.innerHTML="Please Enter Full Name"
                    name_error.classList.add("active");
                    return false;
          }

          name_error.innerHTML='<i class="fa-solid fa-check" style="color: #05d609;"></i>';
          return true;
}

function checkphone()
{
          let phoneno=phone.value;

          if(phoneno.length==0)
          {
                    phone_error.innerHTML="Number Required";
                    phone_error.classList.add("active");
                    return false;
          }
          else if(phoneno.length!=10)
          {
                    phone_error.innerHTML="Enter valid Number";
                    phone_error.classList.add("active");
                    return false;
          }
          else if(!phoneno.match(/^[0-9]{10}$/))
          {
                    phone_error.innerHTML="Enter valid Required";
                    phone_error.classList.add("active");
                    return false;
          }

          phone_error.innerHTML='<i class="fa-solid fa-check" style="color: #05d609;"></i>';
          return true;

}

function checkemail()
{
         

          let emailx=email.value;

          if(emailx.length==0)
          {
                    email_error.innerHTML="Email Required";
                    email_error.classList.add("active");
                    return false;
          }
         
          else if(!emailx.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/))
          {
                    email_error.innerHTML="Enter valid Email";
                    email_error.classList.add("active");
                    return false;
          }
          console.log("Valid");
          email_error.innerHTML='<i class="fa-solid fa-check" style="color: #05d609;"></i>';
          return true;
          

        
}
function checktext()
{
         

          let textx=text.value;
     let required=30;
      let left=required-textx.length;
           if(left>0)
          {
                    text_error.innerHTML=`At least ${left} words required`;
                    text_error.classList.add("active");
                    return false;
          }
          text_error.innerHTML='<i class="fa-solid fa-check" style="color: #05d609;"></i>';
          return true;
          

        
}
function submitbtn()
{
          if(!checkfullname() || !checkphone() || !checkemail() || !checktext())
          {
          
                    button_error.classList.add("active");
                  

                    setTimeout(()=>
                    {
                              button_error.classList.remove("active");
                    },2000);
                    return false;
          }
}



