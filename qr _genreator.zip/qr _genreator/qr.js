const qr=document.querySelector("#qrimage");
const btn=document.querySelector(".btns");
const text=document.getElementById("inputext");
const qrdiv=document.querySelector(".qqrcode");
const cross=document.getElementById("cross");


btn.addEventListener("click",()=>
{
          qrgenerator();
})
text.addEventListener("keyup",(e)=>
{
          if(e.key==="Enter")
          {
                    if(text.value!=="")
                    {
                              qr.src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data="+ text.value;
                              cross.style.opacity=1;
                    }
                    else{
                              alert("Please enter valid url or name")
                    }
          }
})
 function qrgenerator()
{
          if(text.value!=="")
          {
                    qr.src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data="+ text.value;
                   
                    cross.style.opacity=1;
                  

                    

          }
          else{
                    alert("Please enter valid url or name")
          }
                 
          
         
}
cross.addEventListener("click",()=>
{
          text.value="";
          qr.src="";
          cross.style.opacity=0;
          
})
