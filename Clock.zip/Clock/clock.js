


let timer=document.querySelector(".timer");
let stop=document.getElementById("stop");
let start=document.getElementById("start");
let reset=document.getElementById("reset");


let [seconds,minutes,hours]=[0,0,0];

let timerx=null;

function displatime()
{
          seconds++;
          if(seconds===60)
          {
                    seconds=0;
                    minutes++;
                    if(minutes===60)
                    {
                              minutes=0;
                              hours++;
                    }
          }

          let h= hours<10 ? "0"+hours :hours;
          let m= minutes<10 ? "0"+minutes :minutes;
          let s= seconds<10 ? "0"+seconds :seconds;

    timer.innerHTML=`${h} : ${m} :${s}`;
}

function startwatch()
{
          if(timerx!==null)
          {
                    clearInterval(timerx);
          }

          timerx=setInterval(displatime,1000);//setinterval return an id which is stord in timerx to clearinterval we need setinterval id 
}
function stopwatch()
{
          clearInterval(timerx);//timerx is id of setinterval when it is called
}


function resettime()
{
          clearInterval(timerx);
          [seconds,minutes,hours]=[0,0,0];
          timer.innerHTML="00:00:00";

}
start.addEventListener("click",startwatch);

stop.addEventListener("click",stopwatch);

reset.addEventListener("click",resettime);




