let inputfield=document.querySelector("#inputtxt");
let search=document.querySelector("#search");
let more=document.querySelector("#more");
let images=document.querySelector("#searchresult");
let searchform=document.querySelector("#searchform");




let page=1;
const accesskey="-Uf6dEN8RyOSZiviOhHzw3byaa4Xl5tfYj0b387JtPE";
let keyword="";

async function getimage()
{
           keyword=inputfield.value;
          let resposnse=await fetch(`https://api.unsplash.com/search/photos?page=${page}&query=${keyword}&client_id=${accesskey}&per_page=12`);
          let data=await  resposnse.json()

          console.log(data);

          let results=data.results;
          //if one seach is already there and we made new seearch so its necessary to finisj older one
          if(page===1)
          {
                    images.innerHTML="";
          }
          results.map((result)=>
          {
                    let image=document.createElement("img");
                    image.src=result?.urls?.small;

                    let imagelink=document.createElement("a");
                    imagelink.href=result?.links?.html;

                    imagelink.target="_blank";

                    imagelink.appendChild(image);

                     image.classList.add("imgaes");
                    images.appendChild(image);

          


          })
          more.style.opacity=1;
}
searchform.addEventListener("submit",(e)=>
{
         //when ever search is started we need page =1 at starting 
          e.preventDefault();
          page=1;
          getimage();


})
more.addEventListener("click",(e)=>
{
          //show more we increment pages older picture remain same oextra get displayed
  e.preventDefault();
  page++;
  getimage();
})