let display=document.getElementById("txt");
let dropdown=document.querySelector("#drop");
let button=document.querySelector("#btns");

//1it request speech web api which return an object which has text etc
let speech=new SpeechSynthesisUtterance();


//3 let get all the voices
let voices=[];
//this detech voice changed and perform voice changed
// The onvoiceschanged property of the SpeechSynthesis interface represents an event handler that will run when the list of SpeechSynthesisVoice objects that would be returned by the SpeechSynthesis.getVoices() method has changed (when the voiceschanged event fires.)

// This may occur when speech synthesis is being done on the server-side and the voices list is being determined asynchronously, or when client-side voices are installed/uninstalled while a speech synthesis application is running.
window.speechSynthesis.onvoiceschanged=()=>
{
          voices=window.speechSynthesis.getVoices();//we retrieve a list of the voices available using
         
         
         //put voices in dropdown
          voices.forEach((voice,i)=>
          {
                    //this is the way we create option in js
                    dropdown.options[i]=new Option(voice.name,i);
                    
                    (dropdown.options[i]).classList.add("options");
          })
          
        
}

dropdown.addEventListener("change",()=>
{
          speech.voice=voices[dropdown.value];
})


//2apply event listener for speaking
button.addEventListener("click",()=>
{
          speech.text=display.value;
          speech.rate=.6;//speed of pictch
         
          window.speechSynthesis.speak(speech);//this will start utternace of wards
          
})




