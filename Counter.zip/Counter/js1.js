let cvalue=document.querySelector('#counter');

const incre=()=>
{
    let value=parseInt(cvalue.innerText);//we got dtring herto convert wwe have to use parseint

    value=value+1;

    cvalue.innerText=value;
}

const decre=()=>
{
         
                    let value=parseInt(cvalue.innerText);
                    if(value==0)
                    {
                              return;
                    }
                    value=value-1;
                    cvalue.innerText=value;
          
          
}      

