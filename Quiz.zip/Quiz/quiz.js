const questions=[
          {
                    question:"What is not my name ?",
                    answers:[
                              {text:"Deepak",correct:false},
                              {text:"Dwarka",correct:false},
                              {text:"Deepu",correct:false},
                              {text:"Devil",correct:true},
                    ]
          },
          {
                    question:"What is  my fav color ?",
                    answers:[
                              {text:"Red",correct:false},
                              {text:"Blue",correct:true},
                              {text:"Green",correct:false},
                              {text:"Yellow",correct:false},
                    ]
          },
          {
                    question:"What i love most ?",
                    answers:[
                              {text:"Food",correct:false},
                              {text:"Games",correct:false},
                              {text:"God",correct:true},
                              {text:"Myself",correct:false},
                    ]
          },
          {
                    question:"What is my goal?",
                    answers:[
                              {text:"Moksh",correct:true},
                              {text:"Money",correct:false},
                              {text:"Car",correct:false},
                              {text:"Swarg",correct:false},
                    ]
          }
]

const questionelement=document.querySelector(".quiz_question");
const answerbutton=document.querySelector("#answeer_buttons");
const neextbtn=document.querySelector("#btns1");

let currentquestionindex;
let score;

startquiz();

function startquiz()
{
        currentquestionindex=0;
        score=0;
        
        neextbtn.innerText="Next";
        showQuestion();
}

function showQuestion()
{
          resetState();
          let currentquestion=questions[currentquestionindex];

          let currentquestionno=currentquestionindex+1;

          questionelement.innerText=currentquestionno+ ". "+ currentquestion.question;

          currentquestion.answers.forEach((answer)=>
          {
                    let buttonx=document.createElement("button");
                    buttonx.innerText=answer.text;

                    buttonx.classList.add("btns");

                    answerbutton.appendChild(buttonx);



                    if(answer.correct)
                    {
                              buttonx.dataset.correct=answer.correct;
                    }
          
                    buttonx.addEventListener("click",selectanswer)
          

          })
         

         


}

function resetState()
{
          neextbtn.style.display="none";

          while(answerbutton.firstChild)
          {
                    answerbutton.removeChild(answerbutton.firstChild);
          }
}

function selectanswer(e)
{
          const selectbtn=e.target;
          const iscorrect=(selectbtn.dataset.correct==="true");

          if(iscorrect)
          {
                    selectbtn.classList.add("correct");
                    score++;
          }
          else{
                    selectbtn.classList.add("incorrect");
                    
          }
//yeh agr galat select kiya toh correc tmark kr dega
          Array.from(answerbutton.children).forEach((butnx)=>
          {
              if(butnx.dataset.correct==="true")
              {
                    butnx.classList.add("correct");
              }
              butnx.disabled=true;

          })
          neextbtn.style.display="block";


}

function showscore()
{
          resetState();
          questionelement.innerHTML=`Your score is ${score} out of ${questions.length}`;
          neextbtn.innerText="Play Again";
          neextbtn.style.display="flex";
}

function handlenextquestion()
{
          currentquestionindex++;

          if(currentquestionindex<questions.length)
          {
            showQuestion();
          }
          else
          {
                  showscore();
          }
}

neextbtn.addEventListener("click",()=>
{
          if(currentquestionindex<questions.length)
          {
                handlenextquestion();
          }
          else
          {
                    startquiz();
          }
})