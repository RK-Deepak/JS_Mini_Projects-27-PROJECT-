let photo1=document.querySelector("#photo1");
let photo2=document.querySelector("#photo2");
let photo3=document.querySelector("#photo3");
let maininage=document.querySelector("#images");
photo1.addEventListener("click",()=>
{
  maininage.src="432 product-img/image1.png";
})
photo2.addEventListener("click",()=>
{
  maininage.src="432 product-img/image2.png";
})
photo3.addEventListener("click",()=>
{
  maininage.src="432 product-img/image3.png";
})