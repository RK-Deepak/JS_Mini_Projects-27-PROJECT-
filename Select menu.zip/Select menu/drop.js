let selection=document.querySelector("#select");
let roles=document.querySelector("#roles");
let image=document.querySelector("#imgx");

let selectelement=document.querySelector("#selectelement");



function showmenu()
{
          roles.classList.toggle("show")
          image.classList.toggle("rotate")
}

let options=(roles.children);
console.log(options);
// ---1way
for(option of options)
{
          option.onclick=function()
          {
                    selectelement.innerText=this.textContent;
                  roles.classList.toggle("show")
                   image.classList.toggle("rotate")

          }
}
//2-way but to apply this conver options to array
// options.forEach((i)=>
// {
//           i.addEventListener("click",()=>
//           {
//                     selectelement.innerText=i.textContent;
//                     roles.classList.toggle("show")
//                      image.classList.toggle("rotate")
//           })
// })


