const changecolor=document.getElementById("icon");


if(localStorage.getItem("theme")==null)
{
          localStorage.setItem("theme","light");
}

let localdata=localStorage.getItem("theme");

if(localdata=="light")
{
         changecolor.src="moon.png";
         document.body.classList.remove("changepattern");
}
else if(localdata=="dark")
{
          changecolor.src="sun.png";  
          document.body.classList.add("changepattern");
}

changecolor.addEventListener("click",()=>
{
         
                    document.body.classList.toggle("changepattern");
                    if(document.body.classList.contains("changepattern"))
                    {
                              changecolor.src="sun.png";
                              localStorage.setItem("theme","dark");
                    }
                    else{
                              changecolor.src="moon.png";
                              localStorage.setItem("theme","light");
                    }
         

          
})
