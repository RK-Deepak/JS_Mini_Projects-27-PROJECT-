let lists=document.querySelectorAll(".list");
let leftpart=document.querySelector("#left");
let rightpart=document.querySelector("#right");

for(let list of lists)
{            
          //sabhi items ko dragable bana diya pehle he dragable true krke
          //dragstart even is fired when user start dragging an element sabhi list pe laga diya
          list.addEventListener("dragstart",(e)=>
          {
                    let selected=e.target;
                    // You must cancel the default action for ondragenter and ondragover in order for ondrop to fire. In the case of a div, the default action is not to drop. . In order to allow a drag-and-drop action on a div, you must cancel the default action

                    // Yes it is necessary because in the event you're dragging a link, the browser will try to execute that link and not do the drag and drop
                    rightpart.addEventListener("dragover",(e)=>
                    {
                              e.preventDefault();

                            

                    })
                    rightpart.addEventListener("drop",()=>
                    {
                              rightpart.appendChild(selected);
                              selected=null;
                    })

                    leftpart.addEventListener("dragover",(e)=>
                    {
                              e.preventDefault();
                    })
                    leftpart.addEventListener("drop",(e)=>
                    {
                              leftpart.appendChild(selected);
                              selected=null;
                    })
          })
}