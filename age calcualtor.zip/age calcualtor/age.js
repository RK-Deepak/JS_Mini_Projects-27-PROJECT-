let userinput=document.querySelector("#date");
let clacualtebutton=document.querySelector(".btns");
let display=document.querySelector("#display-age");

//lets put the age limit in calender til today

userinput.max=new Date().toISOString().split("T").shift();
//or we can write split("T")[0] ALSO

function calcualateAge()
{
        //input date value
        console.log("called");
   let bd=new Date(userinput.value);

   let d1=bd.getDate();
   let m1=bd.getMonth()+1;//becuase month indexing start form 0
   let y1=bd.getFullYear();

console.log(d1,m1,y1);
   let currentdate=new Date();

   let d2=currentdate.getDate();
   let m2=currentdate.getMonth()+1;
   let y2=currentdate.getFullYear();
   console.log(d1,m1,d2);

   let d3,m3,y3;
//its year
   y3=y2-y1;

   if(m2>=m1)
   {
          m3=m2-m1;
   }
   else //m2=2 and m1=5; a little change
   {
      //decremtn in year since ex-8 2023-m2 and 11-2021 so actual differnce is 1yr 9 month
        y3--;
        m3=12+m2-m1;


   }
   if(d2>=d1)
   {
      d3=d2-d1;
   }
   else //if this is not true we get exact no of days
   {
      m3--;

      d3=getdaysinmonth(y1,m1)+d2-d1;
      //give date difference

      if(m3<0)
      {
         m3=11;
         y3--;
      }
   }


   
      display.innerText=`Your current age is ${y3} years, ${m3} months and ${d3} days.`

      




   }

   function getdaysinmonth(year,month)
   {
      return new Date(year,month,0).getDate();//return max days in that month in that year
   }

   






