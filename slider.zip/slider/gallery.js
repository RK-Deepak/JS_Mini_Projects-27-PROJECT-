let back=document.getElementById("back");
let next=document.getElementById("next");

let app=document.querySelector(".app");

//ROTATE MOUSE WHEEL 
app.addEventListener("wheel",(e)=>
{
          app.scrollLeft+=e.deltaY;
          app.style.scrollBehavior="auto";
})

next.addEventListener("click",()=>
{
          app.style.scrollBehavior="smooth";
          app.scrollLeft+=900;
})

back.addEventListener("click",()=>
{
          app.style.scrollBehavior="smooth";
          app.scrollLeft-=900;
})