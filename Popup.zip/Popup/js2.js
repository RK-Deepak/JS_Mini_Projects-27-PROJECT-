let elementinfo=document.querySelector('#infoid');
let contentblur=document.querySelector('#blurthis');;

let show=()=>
{
          elementinfo.style.transform="translate(-50%,-50%) scale(1)";
          contentblur.classList.add("blur");
          // contentblur.setAttribute("class","blur");when we add class via setattribute otheer class removed
          // $('contentblur').addClass("blur");
}
function hide()
{
          elementinfo.style.transform="translate(-50%,-50%) scale(0)";
          contentblur.classList.remove("blur");
}