let datex=document.querySelector("#date");
let day=document.querySelector("#day");
let month=document.querySelector("#month");
let year=document.querySelector("#year");


let days=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function calendar()
{
          let date=new Date();

          datex.innerHTML=(date.getDate()<10)?"0"+date.getDate():date.getDate();
          day.innerHTML=days[date.getDay()-1];
          month.innerHTML=months[date.getMonth()];
          year.innerHTML=date.getFullYear();

}
calendar();

setInterval(calendar,86400000);



