const  inputslider=document.querySelector("[data-sliderlength]");
const lengthpass=document.querySelector("[data-length_no]");

const passdis=document.querySelector("[data-passworddisplay]");
const copybtn=document.querySelector("[data-copybtn]");

const clipmsg=document.querySelector("[data-copymsg]");

const uppercasetxt=document.querySelector('#uppercase');
const lowercasetxt=document.querySelector('#lowercase');
const numbercasetxt=document.querySelector('#number');
const symbolcasetxt=document.querySelector('#symbol');
const strengthind=document.querySelector("[data-indicator]");
const genratepass=document.querySelector("[data-generatebtns]")
const allcheck=document.querySelectorAll("input[type=checkbox]");
const symbolchar="~%&*{:;}?/|-^*!@#()][.,_=+></*";

let password="";
let passswordlength=10;
let checkcount=1;

strengthind.style.backgroundColor="grey";
strengthind.style.boxShadow="-1px 1px 2px grey ,1px 1px 2px grey";

passdis.classList.add("password");
handleslider();

function handleslider()
{
          inputslider.value=passswordlength;
          lengthpass.innerText=passswordlength;
          const min=inputslider.min;
          const max=inputslider.max;

          inputslider.style.backgroundSize=((passswordlength-min)*100/(max-min))+"%100%";

}
function setIndicator(color)
{
    strengthind.style.backgroundColor=color;
//     strengthind.style.boxShadow="-1px -2px 2px color";
}
function getRandomInteger(min,max)
{
  return Math.floor(Math.random()*(max-min))+min;
}

function generaterrandomNo()
{
  return getRandomInteger(0,9);
}
function generatelowercase()
{
  return String.fromCharCode(getRandomInteger(97,123));

}

function generateuppercase()
{
  return String.fromCharCode(getRandomInteger(65,91));
}

function generateSymbol()
{
  const randnum=getRandomInteger(0,symbolchar.length);

  return symbolchar.charAt(randnum);
}

function calculateStrength()
{
  let uppercase=false;
  let lowercase=false;
  let number=false;
  let symbol=false;//checkbox unticked

  if(uppercasetxt.checked)//.checked property to check value
  {
            uppercase=true;
  }
  
  if(lowercasetxt.checked)
  {
            lowercase=true;
  }
  
  if(numbercasetxt.checked)
  {
            number=true;
  }
  
  if(symbolcasetxt.checked)
  {
            symbol=true;
  }

  if(uppercase && lowercase && (number || symbol) && passswordlength>=8)
  {
    setIndicator("#0f0");
    strengthind.style.boxShadow="-1px 1px 2px #0f0 ,1px 1px 2px #0f0";
  }
  else if((uppercase || lowercase) && (number || symbol) &&pwasswordlength>=6)
  {
            setIndicator("#ff0")
            strengthind.style.boxShadow="-1px 1px 2px #ff0 ,1px 1px 2px #ff0";
  }
  else{
            setIndicator("#f00")
            strengthind.style.boxShadow="-1px 1px 2px #f00 ,1px 1px 2px #f00";
            
  }
}

  async function copypassword()
  {
    try 
    {
      await navigator.clipboard.writeText(passdis.value);
      clipmsg.innerText="Copied";
    }
    catch(e)
    {
      clipmsg.innerText="Failed";
    }
    clipmsg.classList.add("active");

    setTimeout(()=>
    {
      clipmsg.classList.remove("active");
    },2000)
  };


  function handlecheckcount()
  {
    checkcount=0;
    allcheck.forEach((checkx)=>
    {
      if(checkx.checked)
      {
        checkcount++;
      }
    })
    if(passswordlength<checkcount)
    {
      passswordlength=checkcount;
      handleslider();
    }

  }
  allcheck.forEach((checkbox)=>
  {
    checkbox.addEventListener("change",handlecheckcount);
  })

  inputslider.addEventListener("input",(e)=>
  {
    passswordlength=e.target.value;
    handleslider();
  })
  copybtn.addEventListener("click",()=>
  {
    if(passdis.value)
    {
      copypassword();
    }
  })

  function shufflepassword(array)
  {
    for(let i=array.length-1;i>0;i--)
    {
      const j=Math.floor(Math.random()*(i+1));

      const temp=array[i];
      array[i]=array[j];
      array[j]=temp;
    }

    let str="";
    array.forEach((element)=>
    {
      str+=element;
    })
    return str;
  }

  genratepass.addEventListener("click",()=>
  {
    if(checkcount==0)
    {
      return "";
    }
    if(passswordlength<checkcount)
    {
      passswordlength=checkcount;
      handleslider();
    }
    password="";


    let funcArr=[];
    if(uppercasetxt.checked)
    {
              funcArr.push(generateuppercase);
    }
    if(lowercasetxt.checked)
    {
              funcArr.push(generatelowercase);
    }
    if(numbercasetxt.checked)
    {
              funcArr.push(generaterrandomNo);
    }
    if(symbolcasetxt.checked)
    {
              funcArr.push(generateSymbol);
    }

      for(let i=0;i<funcArr.length;i++)
      {
            password+=funcArr[i]();
      }
      for(let i=0;i<passswordlength-funcArr.length;i++)
      {
        let radnomindex=getRandomInteger(0,funcArr.length);

        password+=funcArr[radnomindex]();
      }

        password=shufflepassword(Array.from(password));

        passdis.value=password;
      

      calculateStrength();

  })




