const  inputslider=document.querySelector("[data-sliderlength]");
const lengthpass=document.querySelector("[data-length_no]");

const passdis=document.querySelector("[data-passworddisplay]");
const copybtn=document.querySelector("[data-copybtn]");

const clipmsg=document.querySelector("[data-copymsg]");

const uppercasetxt=document.querySelector('#uppercase');
const lowercasetxt=document.querySelector('#lowercase');
const numbercasetxt=document.querySelector('#number');
const symbolcasetxt=document.querySelector('#symbol');
const strengthind=document.querySelector("[data-indicator]");
const genratepass=document.querySelector("[data-generatebtns]")
const allcheck=document.querySelectorAll("input[type=checkbox]");

const symbolchar="~%&*{:;}?/|-^*!@#()][.,_=+></*"



let password="";
let  pwasswordlength=10;
let checkcount=1;
handleslider();
strengthind.style.backgroundColor="grey";
strengthind.style.boxShadow="-1px 1px 2px grey ,1px 1px 2px grey";

passdis.classList.add("password");
window.addEventListener("load",(e)=>
{
    sessionStorage.clear();
    localStorage.clear();
    

})





function handleslider()
{
          inputslider.value=pwasswordlength;
          lengthpass.innerText=pwasswordlength;
          const min = inputslider.min;
    const max = inputslider.max;
    inputslider.style.backgroundSize = ( (pwasswordlength - min)*100/(max - min)) + "% 100%";

}
function setIndicator(color)
{
    strengthind.style.backgroundColor=color;
//     strengthind.style.boxShadow="-1px -2px 2px color";
}
function getRandomInteger(min,max)
{
        return  Math.floor(Math.random()*(max-min))+min;
}
function generaterrandomNo()
{
          return getRandomInteger(0,9);
}
function generatelowercase()
{
          return String.fromCharCode(getRandomInteger(97,123));
}
function generateuppercase()
{
          return String.fromCharCode(getRandomInteger(65,91));
}
function generateSymbol()
{
          

          const randnum=getRandomInteger(0,symbolchar.length);

          return symbolchar.charAt(randnum);

}

function calculateStrength()
{
          let uppercase=false;
          let lowercase=false;
          let number=false;
          let symbol=false;//checkbox unticked

          if(uppercasetxt.checked)//.checked property to check value
          {
                    uppercase=true;
          }
          
          if(lowercasetxt.checked)
          {
                    lowercase=true;
          }
          
          if(numbercasetxt.checked)
          {
                    number=true;
          }
          
          if(symbolcasetxt.checked)
          {
                    symbol=true;
          }

          if(uppercase && lowercase &&(number || symbol) && pwasswordlength>=8)
          {
                    setIndicator("#0f0");
                    strengthind.style.boxShadow="-1px 1px 2px #0f0 ,1px 1px 2px #0f0";
          }
          else if((uppercase || lowercase) && (number || symbol) &&pwasswordlength>=6)
          {
                    setIndicator("#ff0")
                    strengthind.style.boxShadow="-1px 1px 2px #ff0 ,1px 1px 2px #ff0";
          }
          else{
                    setIndicator("#f00")
                    strengthind.style.boxShadow="-1px 1px 2px #f00 ,1px 1px 2px #f00";
                    
          }

}
          //writetext (navigator.clipboard.writetext(Value)in clipboard to copy text in clipboard return promise
         async function copypassword()
          {
                    try{
                              await navigator.clipboard.writeText(passdis.value);
                              //when promise resolved than only i show copied
                              clipmsg.innerText="Copied";
                    }
                    catch(e)
                    {
                        clipmsg.innerText="Failed";
                    }
                    //to handle clipmsg
                    clipmsg.classList.add("active");

                    setTimeout(()=>
                    {
                             clipmsg.classList.remove("active") 
                    },2000);
            
          }
         

   function shufflepassword(array)
   {
          //fisher yates method--applied on array and shuffle
          for(let i=array.length-1;i>0;i--)
          {
                    const j=Math.floor(Math.random()*(i+1));
                    //swap 
                    const temp=array[i];
                    array[i]=array[j];
                    array[j]=temp;
          }
          let str="";
          array.forEach((el)=>(str+=el));
          return str;
   }
   function handlecheckcount()
   {
             checkcount=0;
             allcheck.forEach((checkx)=>
             {
                       if(checkx.checked)
                       {
                                 checkcount++;
                       }
             })
             //edge case
             if(pwasswordlength<checkcount)
             {
                       pwasswordlength=checkcount;
                       handleslider();
             }
             
   }

        
 
//event listeners
//for checkboc countwhenever checkbox is clicked
allcheck.forEach((checkbox) => {
    checkbox.addEventListener('change',handlecheckcount)
    
});
//for slider
   inputslider.addEventListener('input',(e) =>
   {
          pwasswordlength = e.target.value;
          handleslider();
   })
   copybtn.addEventListener('click',()=>
   {
        if(passdis.value)  
        {
          copypassword();
        }
   })
 

 
genratepass.addEventListener('click',()=>
{
          if(checkcount==0) 
          {
                    return "";
          }
          if(pwasswordlength<checkcount)
          {
                    pwasswordlength=checkcount;
                    handleslider();
          }
          
          //remove old passsword finding new password
          password="";
          

          //first put the stuff which is imp (checkbox ticked)
          //pne way
          // if(uppercasetxt.checked)
          // {
          //           password+=generateuppercase();
          // }
          // if(lowercasetxt.checked)
          // {
          //           password+=generatelowercase();
          // }
          // if(uppercasetxt.checked)
          // {
          //           password+=generaterrandomNo();
          // }
          // if(uppercasetxt.checked)
          // {
          //           password+=generateSymbol();
          // }
          //2 way
          //first put fn in array to we can access any dn randow
           let funcArr=[];
          if(uppercasetxt.checked)
          {
                    funcArr.push(generateuppercase);
          }
          if(lowercasetxt.checked)
          {
                    funcArr.push(generatelowercase);
          }
          if(numbercasetxt.checked)
          {
                    funcArr.push(generaterrandomNo);
          }
          if(symbolcasetxt.checked)
          {
                    funcArr.push(generateSymbol);
          }

          //compulsay addition

          for(let i=0;i<funcArr.length;i++)
          {
              password+=funcArr[i]();
          }
        //   console.log("COmpulsory adddition done");
          // remaining addition
          for(let i=0;i<pwasswordlength-funcArr.length;i++)
          {
              let radnomindex=getRandomInteger(0,funcArr.length);
            //   console.log("randIndex" + radnomindex);
              password+=funcArr[radnomindex]();
          }
          console.log("Remaining adddition done");
     //shuffle and push 
          password=shufflepassword(Array.from(password));
        //   console.log("Shuffling done");

          
          passdis.value=password;
          
          
          
        //   console.log("UI adddition done");

          calculateStrength();


});






