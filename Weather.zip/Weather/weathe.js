const usertab=document.querySelector("[data-urweather]");
const searchtab=document.querySelector("[data-seaweather]");
const geolocatex=document.querySelector("[data-geolocation]");
const geobtn=document.querySelector("[data-geobtn]");
const searchform=document.querySelector("[data-searchform]");
const searchinput=document.querySelector("[data-searchinput]");
const dataloading=document.querySelector("[data-loading]");
const mainsection=document.querySelector("[data-mainsection]");
const cityd=document.querySelector("[data-city]");
const country=document.querySelector("[data-country]");
const surroundings=document.querySelector("[data-surrounding]");
const surrImage=document.querySelector("[data-surrimage]");
const temp=document.querySelector("[data-temp]");
const windsp=document.querySelector("[data-windspeed]");
const humid=document.querySelector("[data-humidity]");
const clouds=document.querySelector("[data-cloud]");

const errorx=document.querySelector("[data-error]");
const API_KEY="82744c525e42af356f3c89d8941cbcfd";
let currenttab=usertab;
//woh background aata na tab ka woh
currenttab.classList.add("currnttab");

getSessionStorage();

function switchtab(clicktab)
{
  if(clicktab!=currenttab)
  {
    //woh background aata na tab ka woh
       currenttab.classList.remove("currnttab");
       currenttab=clicktab;
       currenttab.classList.add("currnttab");

       //ab search tab activate nhi hai mtlb search tab activate krna kyunki hum starting me weather pe the
       if(!searchform.classList.contains("active"))
       {
        mainsection.classList.remove("active");
        geolocatex.classList.remove("active");
        searchform.classList.add("active");
        
       }
       //search pe the ab ur waether pe aaye
       else
       {
           searchform.classList.remove("active");
           mainsection.classList.add("active");
           getSessionStorage();
       }

       

  }
}

usertab.addEventListener("click",()=>
{
    switchtab(usertab);
})
searchtab.addEventListener("click",()=>
{
  switchtab(searchtab);
})

//get localstorage //we use session storage not locla because we want ke sirf refresh ho ya same apge pe data ho another tab me jaye toh data na h0

function getSessionStorage()
{
  const localcoordinates=sessionStorage.getItem("user-coordinates");
  if(!localcoordinates)
  {
    geolocatex.classList.add("active");
  }
  else 
  {
    const coordinates=JSON.parse(localcoordinates);
    fetchweatherCondition(coordinates);
  }
}

//we are using api herwe can use promise or async/await

async function fetchweatherCondition(coordinates)
{
  //destrucuting

  const {lat,lon}=coordinates;

  geolocatex.classList.remove("active");

  dataloading.classList.add("active");

  try 
  {
    let response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`
    );
  const  data = await response.json();

  dataloading.classList.remove("active");

  //now its time to retrieve the data and use it

  retrieveinfo(data);

  }
  catch(e)
  {
    dataloading.classList.remove("active");
  }
}
function retrieveinfo(weatherinfo)
{
  cityd.innerText = weatherinfo?.name;
  country.src = `https://flagcdn.com/144x108/${weatherinfo?.sys?.country.toLowerCase()}.png`;
  surroundings.innerText = weatherinfo?.weather?.[0]?.description;
  surrImage.src = `http://openweathermap.org/img/w/${weatherinfo?.weather?.[0]?.icon}.png`;
  temp.innerText = `${weatherinfo?.main?.temp} °C`;
  windsp.innerText = weatherinfo?.wind?.speed;
  humid.innerText = weatherinfo?.main?.humidity;
  clouds.innerText = weatherinfo?.clouds?.all;

  mainsection.classList.add("active");
  

}

//get current location using geolocation

function gerlocation()
{
  if(navigator.geolocation)
  {
    navigator.geolocation.getCurrentPosition(showPosition);
  }
  else 
  {
    window.alert("Geolocation not available");
  }
  geolocatex.classList.remove("active");
}

function showPosition(position)
{
  let usercoordinates=
  {
    lat:position.coords.latitude,
    lon:position.coords.longitude
  }

  sessionStorage.setItem("user-coordinates",JSON.stringify(usercoordinates));

  fetchweatherCondition(usercoordinates);
   
}
geobtn.addEventListener("click",gerlocation);


let searchbtn=document.querySelector("#btnssearch");

searchbtn.addEventListener("click",()=>
{
  let cityx=searchinput.value;
  if(cityx==="")
  {
    return;
  }
  else 
  {
    weatherbycity(cityx);
  }
  errorx.classList.remove("active");
})

searchform.addEventListener("submit",(e)=>
{
  e.preventDefault();
  let cityx=searchinput.value;
  if(cityx==="")
  {
    return;
  }
  else 
  {
    weatherbycity(cityx);
  }
  errorx.classList.remove("active");

})

async function weatherbycity(cityx)
{
  dataloading.classList.add("active");
  mainsection.classList.remove("active");
  // geolocatex.classList.remove("active");


  try 
  {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${cityx}&appid=${API_KEY}&units=metric`
    );
  const data = await response.json();

  if(!data.sys)
  {
    throw data;
  }

     
  dataloading.classList.remove("active");

  errorx.classList.remove("active");
  retrieveinfo(data)
  }
  catch(e)
  {
    dataloading.classList.remove("active");
    errorx.classList.add("active");
    console.log(`${e?.message}`);
  }
}