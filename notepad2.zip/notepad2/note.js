const note_container=document.querySelector(".notes_container");
const butt=document.querySelector("#btns");
let notes=document.querySelectorAll(".input_box");

butt.addEventListener("click",()=>
{
          console.log("called");
          let createnote=document.createElement("p");
          let imgx=document.createElement("img");
          createnote.className="input_box";
          createnote.setAttribute("contenteditable","true");

         
          imgx.src="images/delete.png";

         note_container.appendChild(createnote).appendChild(imgx);
         savedata();
})


note_container.addEventListener("click",(e)=>
{
          if(e.target.tagName==="IMG")
          {
                    e.target.parentElement.remove();
                    savedata();
          }

          //jo bhilikha hai sab save hoga jaise 
          else if(e.target.tagName=="P")
          {
                    //give us div which has all p and everything
                    notes=document.querySelectorAll(".notes_container");
                    
                    notes.forEach(nt=>
                              {
                                      //nt give enotes constiaer with updated div verytime wh click  
                                        nt.onkeyup=function()
                                        {
                                                  savedata();
                                        }
                              })
                        
          }
          
})

//enter key to break line

document.addEventListener("keydown",(e)=>
{
          if(e.key==="Enter")
          {
                    e.preventDefault();
                    document.execCommand("insertLineBreak");
          }
})

function savedata()
{
          localStorage.setItem("notes",note_container.innerHTML);
}
showData();
function showData()
{
         note_container.innerHTML=localStorage.getItem("notes")
}






         

          



          





