let hours=document.querySelector("#hrs");
let minutes=document.querySelector("#min");
let seconds=document.querySelector("#sec");








     
          

let timer=setInterval(()=>
{
          let date=new Date();
          hours.innerHTML=(date.getHours()<10 )?"0"+date.getHours():date.getHours();
          minutes.innerHTML=(date.getMinutes()<10 )?"0"+date.getMinutes():date.getMinutes();
          seconds.innerHTML=(date.getSeconds()<10 )?"0"+date.getSeconds():date.getSeconds();
          
          
},1000);





