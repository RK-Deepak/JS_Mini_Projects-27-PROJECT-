


let quotedata=document.querySelector("#quote");
let author=document.querySelector("#author");
let hyphen=document.querySelector(".hypen");


const apiurl="https://api.quotable.io";

async function getquote()
{
          let data=await fetch(apiurl+"/random");

          let readable= await data.json();
        

          quotedata.innerText=readable?.content;
          author.innerText=readable?.author;

      hyphen.style.display="block";
      quotedata.classList.add("active");

         


}

getquote(apiurl+"/random");

function ontweet()
{
          window.open("https://twitter.com/intent/tweet?text="+quotedata.innerText + "----by"+ author.innerText,"Tweet Window","width=600px ,height=300px" );//twet window is name of window and 3 parameter is dimenion of window
}


