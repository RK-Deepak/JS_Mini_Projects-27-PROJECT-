const url = "https://api.github.com/users/";
const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const avtar=document.querySelector("[data-avtar]");
const profilename=document.getElementById("profile_name");
const joindate=document.getElementById("datejoin");
const profileid=document.querySelector("[data-profileid]");
const profileinfo=document.querySelector("[data-profileinfo]");
const repo=document.querySelector("[data-repo]");
const repono=document.querySelector("[data-repono]");
const follower=document.querySelector("[data-follower]");
const followeno=document.querySelector("#followerno");
const following=document.querySelector("[data-following]");
const followingno=document.querySelector("#followings");
// const noresults = document.getElementById("no-results");
const user=document.getElementById("user");
const searchbar=document.querySelector("#search_bar");
const dataprfmain=document.querySelector(".profile_info");
const locate=document.querySelector("#data-location");
const website=document.querySelector("#data-website");
const twitter=document.querySelector("[data-twitter]");
const company=document.querySelector("[data-company]");
const submit=document.querySelector("#search_button");
const input=document.getElementById("inputtxt");
const errorimage=document.querySelector(".imageserror");
const modeinfo=document.querySelector("[data-modeinfo]");
const modeicon=document.querySelector("[data-modeicon]");
const btnmode=document.querySelector("#screen");
const wrappper=document.querySelector(".wrapper");
//first i need some data

submit.addEventListener("click",function()
{
          if(input.value!=="")
          {
                    getuserdata(url + input.value);
          }
});
input.addEventListener("keydown",function(e)
{
          if(e.key=="Enter")
          {
                 if(input.value!=="")
                 {
                    getuserdata(url + input.value);
                 }
          }

},
 false
)
// input.addEventListener("click",function()
// {
//           noresults.style.display="none";
// })



function getuserdata(giturl)
{
          fetch(giturl)
          .then((response)=>response.json())
          .then((data)=>
          {
                    console.log(data);
                    updateprofile(data);
          })
          .catch((error)=>
          {
               throw error;
          })
}
function updateprofile(data)
{
          if(data.message!=="Not Found")
          {
                // noresults.style.display="none";
          
          function checkavailable(param1,param2)
          {
                    if(param1==="" || param1===null)
                    {
                              param2.style.opacity = 0.5;
                              param2.previousElementSibling.style.opacity = 0.5;

                              return false;


                    }
                    else{
                              return true;
                    }
          }
          avtar.src = `${data.avatar_url}`;
          profilename.innerText = data.name === null ? data.login : data.name;
          profileid.innerText = `@${data.login}`;
          user.href = `${data.html_url}`;
          datesegments = data.created_at.split("T").shift().split("-");
          joindate.innerText = `Joined ${datesegments[2]} ${months[datesegments[1] - 1]} ${datesegments[0]}`;
          profileinfo.innerText = data.bio == null ? "This profile has no bio" : `${data.bio}`;
          repono.innerText = `${data.public_repos}`;
          followeno.innerText = `${data.followers}`;
          followingno.innerText = `${data.following}`;
          locate.innerText = checkavailable(data.location, locate) ? data.location : "Not Available";
          website.innerText = checkavailable(data.blog, website) ? data.blog : "Not Available";
          // website.href = checkavailable(data.blog, website) ? data.blog : "#";
          twitter.innerText = checkavailable(data.twitter_username, twitter) ? data.twitter_username : "Not Available";
          // twitter.href = checkavailable(data.twitter_username, twitter) ? `https://twitter.com/${data.twitter_username}` : "#";
          company.innerText = checkavailable(data.company, company) ? data.company : "Not Available";
          // searchbar.classList.toggle("active");
          dataprfmain.classList.remove("inactive");
          errorimage.classList.remove("active");

          
        } else {
          // noresults.style.display = "block";
          dataprfmain.classList.add("inactive");
          errorimage.classList.add("active");

        }
}



//SWITCH TO DARK MODE - activateDarkMode()

        
        //SWITCH TO LIGHT MODE - activateLightMode()
        

        function init()
{
          getuserdata(url+ "lovebabbar" );

      

        //   HW
        // const prefersDarkMode = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
      
          
        
}
init();

//dark mode

if(localStorage.getItem("theme")==null)
{
  localStorage.setItem("theme","light");
}

let localdata=localStorage.getItem("theme");

if(localdata=="light")
{
  modeinfo.innerText="Dark";
  modeicon.src="moon.png";
  wrappper.classList.remove("dark_theme");
}
else
{
  modeinfo.innerText="Light";
  modeicon.src="sun.png";
  wrappper.classList.add("dark_theme");
}

modeicon.addEventListener("click",()=>
{
     wrappper.classList.toggle("dark_theme");
      if(wrappper.classList.contains("dark_theme"))
      {
        modeinfo.innerText="Light";
        modeicon.src="sun.png";
        localStorage.setItem("theme","dark");
      }
      else{
        modeinfo.innerText="Dark";
        modeicon.src="moon.png";
        localStorage.setItem("theme","light");
      }
});

