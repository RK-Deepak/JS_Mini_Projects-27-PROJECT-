const inputfeild=document.getElementById("input_box");
const add=document.querySelector("#btns");
const list=document.querySelector("#list");
const input_form=document.querySelector(".input_field");

function addtask()
{
         
          if(inputfeild.value==="")
          {
                    alert("Please Write something");
          }
          else
          {
                    let li=document.createElement("li");
                    li.innerText=inputfeild.value;
                    list.appendChild(li);

                    //cross mark

                    let span=document.createElement("span");
                    span.innerHTML="\u00d7";
                    li.appendChild(span);
          }
          inputfeild.value="";
          saveData();

}
input_form.addEventListener("keydown",(e)=>
{
         
          if(e.key=="Enter")
          {
                    if(inputfeild.value==="")
                    {
                              alert("Please Write something");
                    }
                    else
                    {
                              let li=document.createElement("li");
                              li.innerText=inputfeild.value;
                              list.appendChild(li);
          
                              //cross mark
          
                              let span=document.createElement("span");
                              span.innerHTML="\u00d7";
                              li.appendChild(span);
                    }
                    inputfeild.value="";
                    saveData();
          }
      
})
list.addEventListener("click",(e)=>
{
          if(e.target.tagName==="LI")
          {
                    e.target.classList.toggle("checked");
                    saveData();
          }
          if(e.target.tagName=="SPAN")
          {
                    e.target.parentElement.remove();
                    saveData();
          }
})


//know lets save data

function saveData()
{
          localStorage.setItem("data",list.innerHTML);
}
//to show ehen we start

function showTask()
{
          list.innerHTML=localStorage.getItem("data");
}
showTask();
