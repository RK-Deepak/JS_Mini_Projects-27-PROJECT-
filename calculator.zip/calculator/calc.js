let grids=Array.from(document.querySelectorAll(".perform"));
let clearall=document.querySelector(".clears");
let deleteone=document.querySelector(".deleteone ");
let equal=document.querySelector(".equality");
let display=document.getElementById("dis");





          


grids.forEach((element)=>(
          element.addEventListener("click",()=>
          {
                    display.value+=element.innerText;
                    
          })
         
          
          
))

clearall.addEventListener("click",(e)=>
{
          e.preventDefault();
          display.value="";
})
deleteone.addEventListener("click",(e)=>
{
          e.preventDefault();
          display.value=display.value.slice(0,-1);
          // display.value=display.value.substr(0,display.value.length -1);

})
equal.addEventListener("click",(e)=>
{
          e.preventDefault();
          display.value=eval(display.value);
  
})


